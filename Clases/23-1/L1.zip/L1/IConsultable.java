interface IConsultable{
    String consultarDatos();
}