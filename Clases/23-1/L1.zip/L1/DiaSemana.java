enum DiaSemana{
    Lunes, Martes, Miercoles, Jueves, Viernes, Sabado
}